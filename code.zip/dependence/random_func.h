extern void init_random(unsigned char seed);
extern unsigned char random(void);