extern void EX0_init(void);
extern void EX1_init(void);
extern void TIM_0_init(void);
extern void TIM_1_init(void);